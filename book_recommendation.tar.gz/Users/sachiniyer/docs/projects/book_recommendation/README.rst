:Author: Sachin Iyer

Book Recommendation
===================

This is to assign manually generated tags to a list of books using
wikipedia pages with `this <https://pypi.org/project/wikipedia/>`__
library.

To use, put books in the books.txt file, and tags in the tags.txt file.
